# *******************************************************
# Name: Lucas Liu
# UNI: yl3433
# hw5b module
# Assignment 6 Part 1
# ENGI E1006
# *******************************************************

For nn.py

I chose euclidean distance as the distance for finding the nearest neighbor. The output should be n-1 dimensional vector whose elements are the labels.

For n_valudator.py

To slice the data set as evenly as possible, I first split the data into p sections and then 1 to first a 
couple sections until it exhausts the remainder

Then for each test data set, I apply the classifier once. Then I compare the output labels one by one with the 
correct labels. A score is calculated to indicate the number of correct labels. 

Divide the final score by the row number to get the percentage of correct labeling.