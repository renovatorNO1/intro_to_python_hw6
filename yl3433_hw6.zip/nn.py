# *******************************************************
# Name: Lucas Liu
# UNI: yl3433
# hw5b module
# Assignment 6 Part 1
# ENGI E1006
# *******************************************************

import numpy as np
from scipy.spatial import distance

def NNclassifier(training, test):
    '''classify the test data with labels provided by training data by applying nearest
        neighbor algorithm. The out put is a numpy array of labels for each data point'''
    #Store #of rows of test into variable row_num
    row_num = test.shape[0]
    
    #Specify the dimension of the ourput array
    order = np.zeros(row_num)
    
    #Create a numpy array whose elements are the values of distance from every pair of points    
    d = distance.cdist(test[:, 1:], training[:, 1:],'euclidean')
    
    #Rearrange elements of each row of d in ascending order, represented by their indice
    d_order = d.argsort()
    
    #take the indice of minimum distance 
    d_min = d_order[:, 0]
    
    #Modify each element of order. Turn it into a vector with all the labels for test data set
    for x in range(test.shape[0]):
        min_distance = d_min[x]
        order[x] = training[min_distance][0]
    
    #Specify the shape of order to meet the output qualification
    order = order.reshape(row_num,1)
    
    return order
    
def n_validator(data, p, classifier, *arg):
    '''Estimate the performance of the NNclassifier function with a real data set. The output 
       is a float between 0 and 1 that measures the performance of the classifier. Higher score
       indicates higher accuracy of the classifer function.'''
       
    #Store #of rows of data into the variable n    
    n = data.shape[0]
    
    #The following codes are intended to divide the data into p parts as evenly as possible
    #so that no single section has more than one observation than any other section.
    remainder = n % p
    sections = np.array([n//p]*p)
    sections[:remainder] += 1
    
    #Initiate counter. Use k to keep track of sections. 
    #Use score to keep track of the accuracy of labels
    k = 0
    score = 0

    #Loop p times to make sure every section gets treated as test data set for one time    
    for i in range(p):
        
        #Specify the test data set and training data set
        test = data[k:k+sections[i]]
        training = np.delete(data, range(k, k+sections[i]), 0)
        
        #Increment k so next loop will start on a new section
        k = k + sections[i]
        
        #Call the calssifier function 
        labels = classifier(training, test)
        
        #Increase score by 1 for each correct label        
        for x in range(labels.shape[0]):
            if labels[x] == test[x][0]:
                score += 1
    
    #Return the percentage of correct labels
    return score/n



    

    
            
            
            
            

