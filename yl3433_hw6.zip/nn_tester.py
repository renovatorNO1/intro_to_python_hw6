# *******************************************************
# Name: Lucas Liu
# UNI: yl3433
# hw5b module
# Assignment 6 Part 1
# ENGI E1006
# *******************************************************

import matplotlib.pyplot as plt
import numpy as np
import nn
def synthetic_data():
    '''Generate two classes of data set using multivariate normal distribution.
        Combine the two to create a synthetic data set'''
    m1 = [2.5, 3.5]
    m2 = [0.5, 1]
    cov1 = [[1,1],[1,4.5]]
    cov2 = [[2,0],[0,1]]
    x1 = np.random.multivariate_normal(m1, cov1, 200)
    x2 = np.random.multivariate_normal(m2, cov2, 300)

    plt.plot(x1[:,0],x1[:,1],'ro',x2[:,0],x2[:,1],'bo')
    plt.show()
    
    labels1 = np.ones(200).reshape(200,1)
    x1_labels = np.hstack((x1, labels1))
    x1_labels.shape
    
    labels2 = 2 * np.ones(300).reshape(300,1)
    x2_labels = np.hstack((x2, labels2))
    x2_labels.shape
    
    data = np.vstack((x1_labels, x2_labels))
    data[:,[0, 2]] = data[:,[2, 0]]
    
    np.random.shuffle(data)
    
    return data
    
data1 = synthetic_data() 

with open('wdbc.txt', 'r') as infile:
    '''Import a real data set from wdbc.txt'''
    temp_data = []
    for line in infile:
        line = line.split()
        temp_data.append(line)
        
temp_data = np.array(temp_data)
temp_data = temp_data.astype(float)
data_set = np.delete(temp_data, 0, 1)
    
print("The score for classifying a synthetic data set is")
print(nn.n_validator(data1, 5, nn.NNclassifier))

print("The score for classifying a real data set is")
print(nn.n_validator(data_set, 5, nn.NNclassifier))